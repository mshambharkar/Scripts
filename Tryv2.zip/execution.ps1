﻿
#from user
$targetdirectory = "C:\Users\zombiewin\Downloads\Tryv2"
$ostarget = "win10Pro"


#calculate
$sourceiso = "$targetdirectory\iso\$ostarget\os.iso"
$packerjson = "$targetdirectory\configs\$ostarget\packer.json"
$vagranttemplate = "$targetdirectory\configs\$ostarget\vagrant.template"
$prebootiso = "$targetdirectory\iso\$ostarget\prebootos.iso"
$prebootUnattend = "$targetdirectory\configs\$ostarget\prebootAutoUnattend.xml"
$sourcepackage = "$targetdirectory\setup"
$sourcescripts = "$targetdirectory\scripts"
$packerexepath= "$targetdirectory\tools\packer.exe"
function PreBootOS {
    param (
        $SourceIso,
        $DestIso,
        $Autounattendxmlpath,
        $Sourcepackages,
        $CustomScripts
    )
    if(Test-Path -Path $DestIso)
    {
        return
    }


    Write-Host "Creating Pre boot OS"
    $tools = 'C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\oscdimg'
    $oscdimg = "$tools\oscdimg.exe"
    $etfsboot = "$tools\etfsboot.com"
    $efisys = "$tools\efisys.bin"
    
    # mount the existing iso.
    $mount = mount-diskimage -imagepath $SourceIso -passthru
    
    # get the drive letter assigned to the iso.
    $drive = ($mount | get-volume).driveletter + ':'
    
    # create a temp folder for extracting the existing iso.
    $workspace = "{0}\{1}" -f $env:temp, [system.guid]::newguid().tostring().split('-')[0]
    new-item -type directory -path $workspace
    
    # extract the existing iso to the temporary folder.
    copy-item $drive\* $workspace -force -recurse
    
    # remove the read-only attribtue from the extracted files.
    get-childitem $workspace -recurse | % { if (! $_.psiscontainer) { $_.isreadonly = $false } }
    
    #read-host
    copy-item $Autounattendxmlpath $workspace  -force -recurse
    Rename-Item -Path "$workspace\prebootAutoUnattend.xml" -NewName "AutoUnattend.xml" -Confirm:$false
    copy-item $Sourcepackages "$workspace\sources\`$OEM`$\`$1"  -force -recurse
    copy-item $CustomScripts "$workspace\sources\`$OEM`$\`$1"  -force -recurse
    
    # create the updated iso.
    $data = '2#p0,e,b"{0}"#pEF,e,b"{1}"' -f $etfsboot, $efisys
    start-process $oscdimg -args @("-bootdata:$data", '-u2', '-udfver102', $workspace, $DestIso) -wait -nonewwindow
    
    # remove the extracted content.
    remove-item $workspace -recurse -force
    
    # dismount the iso.
    dismount-diskimage -imagepath $SourceIso
    Write-Host "Done Pre boot OS"
}


function Updatepackerjson {
    param (
        $packerfile,
        $isofile
    )

    Write-Host "Updating Json File [$packerfile]"
    $a = Get-Content $packerfile -raw | ConvertFrom-Json
    
    if ([string]::IsNullOrWhiteSpace($a.variables.iso_checksum)) {
        $calculatedhash = Get-FileHash -Path $isofile -Algorithm SHA256    
        $a.variables.iso_checksum = $calculatedhash.Hash
        $a.variables.iso_url = $isofile
        $a.variables.iso_checksum_type = "sha256"
        $a | ConvertTo-Json -depth 32 | set-content $packerfile    
    }
    Write-Host "Done Updating Json File [$packerfile]"
}

#processing

$stopwatch = [system.diagnostics.stopwatch]::StartNew()
PreBootOS -SourceIso $sourceiso -DestIso $prebootiso -Autounattendxmlpath $prebootUnattend -Sourcepackages $sourcepackage -CustomScripts $sourcescripts
$stopwatch.Stop()
Write-Host "Done Preboot OS file [$prebootiso] , Time taken -[$stopwatch.Elapsed.TotalMinutes]"
$stopwatch.Start()
Updatepackerjson -packerfile $packerjson -isofile $prebootiso
$stopwatch.Stop()
Write-Host "Done Updating Json File [$packerjson] - Time in minutes [$stopwatch.Elapsed.TotalMinutes]"

& $packerexepath build --force $packerjson





